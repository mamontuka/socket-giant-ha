﻿
namespace Socket_Giant_Protocol
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.imgListConnection = new System.Windows.Forms.ImageList(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.labelURL = new System.Windows.Forms.Label();
            this.imgListDirection = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblConState = new System.Windows.Forms.Label();
            this.picConState = new System.Windows.Forms.PictureBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtIPaddress = new System.Windows.Forms.MaskedTextBox();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtIPport = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tmrConState = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.btnCmd04 = new System.Windows.Forms.Button();
            this.lstEvents = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnCmd03 = new System.Windows.Forms.Button();
            this.btnCmd02 = new System.Windows.Forms.Button();
            this.btnCmd01 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cmbCmd20_1 = new System.Windows.Forms.ComboBox();
            this.cmbCmd21_0 = new System.Windows.Forms.ComboBox();
            this.cmbCmd20_0 = new System.Windows.Forms.ComboBox();
            this.nmCmd20_2 = new System.Windows.Forms.NumericUpDown();
            this.btnCmd21 = new System.Windows.Forms.Button();
            this.btnCmd20 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.picRel15 = new System.Windows.Forms.PictureBox();
            this.picRel14 = new System.Windows.Forms.PictureBox();
            this.picRel13 = new System.Windows.Forms.PictureBox();
            this.picRel12 = new System.Windows.Forms.PictureBox();
            this.picInp15 = new System.Windows.Forms.PictureBox();
            this.picInp14 = new System.Windows.Forms.PictureBox();
            this.picInp13 = new System.Windows.Forms.PictureBox();
            this.picInp12 = new System.Windows.Forms.PictureBox();
            this.picRel11 = new System.Windows.Forms.PictureBox();
            this.picRel10 = new System.Windows.Forms.PictureBox();
            this.picRel09 = new System.Windows.Forms.PictureBox();
            this.picRel08 = new System.Windows.Forms.PictureBox();
            this.picInp11 = new System.Windows.Forms.PictureBox();
            this.picInp10 = new System.Windows.Forms.PictureBox();
            this.picInp09 = new System.Windows.Forms.PictureBox();
            this.picInp08 = new System.Windows.Forms.PictureBox();
            this.picRel07 = new System.Windows.Forms.PictureBox();
            this.picRel06 = new System.Windows.Forms.PictureBox();
            this.picRel05 = new System.Windows.Forms.PictureBox();
            this.picRel04 = new System.Windows.Forms.PictureBox();
            this.picInp07 = new System.Windows.Forms.PictureBox();
            this.picInp06 = new System.Windows.Forms.PictureBox();
            this.picInp05 = new System.Windows.Forms.PictureBox();
            this.picInp04 = new System.Windows.Forms.PictureBox();
            this.picRel03 = new System.Windows.Forms.PictureBox();
            this.picRel02 = new System.Windows.Forms.PictureBox();
            this.picRel01 = new System.Windows.Forms.PictureBox();
            this.picRel00 = new System.Windows.Forms.PictureBox();
            this.picInp03 = new System.Windows.Forms.PictureBox();
            this.picInp02 = new System.Windows.Forms.PictureBox();
            this.picInp01 = new System.Windows.Forms.PictureBox();
            this.picInp00 = new System.Windows.Forms.PictureBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chkRel15 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.chkRel14 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.chkRel13 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.chkRel12 = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.chkRel11 = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.chkRel10 = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.chkRel09 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.chkRel08 = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.chkRel07 = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.chkRel06 = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.chkRel05 = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.chkRel04 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chkRel03 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.chkRel02 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkRel01 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chkRel00 = new System.Windows.Forms.CheckBox();
            this.btnCmd25 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbCmd22_1 = new System.Windows.Forms.ComboBox();
            this.cmbCmd22_0 = new System.Windows.Forms.ComboBox();
            this.nmCmd22_2 = new System.Windows.Forms.NumericUpDown();
            this.btnCmd23 = new System.Windows.Forms.Button();
            this.btnCmd22 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picConState)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmCmd20_2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmCmd22_2)).BeginInit();
            this.SuspendLayout();
            // 
            // imgListConnection
            // 
            this.imgListConnection.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListConnection.ImageStream")));
            this.imgListConnection.TransparentColor = System.Drawing.Color.Transparent;
            this.imgListConnection.Images.SetKeyName(0, "Conn_Red");
            this.imgListConnection.Images.SetKeyName(1, "Conn_Blue");
            this.imgListConnection.Images.SetKeyName(2, "Conn_Green");
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(442, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 14);
            this.label6.TabIndex = 25;
            this.label6.Text = "0-255";
            // 
            // labelURL
            // 
            this.labelURL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelURL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(100)))), ((int)(((byte)(0)))));
            this.labelURL.Location = new System.Drawing.Point(85, 9);
            this.labelURL.Name = "labelURL";
            this.labelURL.Size = new System.Drawing.Size(111, 22);
            this.labelURL.TabIndex = 70;
            this.labelURL.Text = "vkmodule.com.ua";
            this.labelURL.Click += new System.EventHandler(this.LabelURLClick);
            // 
            // imgListDirection
            // 
            this.imgListDirection.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgListDirection.ImageStream")));
            this.imgListDirection.TransparentColor = System.Drawing.Color.Transparent;
            this.imgListDirection.Images.SetKeyName(0, "1.jpg");
            this.imgListDirection.Images.SetKeyName(1, "2.jpg");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblConState);
            this.groupBox1.Controls.Add(this.picConState);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtIPaddress);
            this.groupBox1.Controls.Add(this.btnDisconnect);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.txtIPport);
            this.groupBox1.Location = new System.Drawing.Point(12, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(201, 144);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connection";
            // 
            // lblConState
            // 
            this.lblConState.AutoSize = true;
            this.lblConState.Location = new System.Drawing.Point(74, 116);
            this.lblConState.Name = "lblConState";
            this.lblConState.Size = new System.Drawing.Size(39, 13);
            this.lblConState.TabIndex = 56;
            this.lblConState.Text = "Closed";
            // 
            // picConState
            // 
            this.picConState.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picConState.BackgroundImage")));
            this.picConState.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picConState.Location = new System.Drawing.Point(44, 110);
            this.picConState.Name = "picConState";
            this.picConState.Size = new System.Drawing.Size(24, 24);
            this.picConState.TabIndex = 55;
            this.picConState.TabStop = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(62, 50);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 13);
            this.label35.TabIndex = 54;
            this.label35.Text = "Port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 53;
            this.label1.Text = "IP address";
            // 
            // txtIPaddress
            // 
            this.txtIPaddress.Location = new System.Drawing.Point(100, 20);
            this.txtIPaddress.Name = "txtIPaddress";
            this.txtIPaddress.Size = new System.Drawing.Size(79, 20);
            this.txtIPaddress.TabIndex = 49;
            this.txtIPaddress.Text = "192.168.0.191";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Location = new System.Drawing.Point(14, 73);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(78, 26);
            this.btnDisconnect.TabIndex = 52;
            this.btnDisconnect.Text = "Close";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.BtnDisconnectClick);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(101, 73);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(78, 26);
            this.btnConnect.TabIndex = 51;
            this.btnConnect.Text = "Open";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnectClick);
            // 
            // txtIPport
            // 
            this.txtIPport.Location = new System.Drawing.Point(100, 47);
            this.txtIPport.Name = "txtIPport";
            this.txtIPport.Size = new System.Drawing.Size(79, 20);
            this.txtIPport.TabIndex = 50;
            this.txtIPport.Text = "9761";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(172, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            // 
            // tmrConState
            // 
            this.tmrConState.Enabled = true;
            this.tmrConState.Interval = 500;
            this.tmrConState.Tick += new System.EventHandler(this.TmrConStateTick);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(358, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 17);
            this.label2.TabIndex = 17;
            this.label2.Text = "Bounce *20ms";
            // 
            // btnCmd04
            // 
            this.btnCmd04.Location = new System.Drawing.Point(23, 128);
            this.btnCmd04.Name = "btnCmd04";
            this.btnCmd04.Size = new System.Drawing.Size(206, 25);
            this.btnCmd04.TabIndex = 6;
            this.btnCmd04.Text = "0x04 UID request";
            this.btnCmd04.UseVisualStyleBackColor = true;
            this.btnCmd04.Click += new System.EventHandler(this.btnCmd04_Click);
            // 
            // lstEvents
            // 
            this.lstEvents.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lstEvents.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader3});
            this.lstEvents.FullRowSelect = true;
            this.lstEvents.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstEvents.HideSelection = false;
            this.lstEvents.Location = new System.Drawing.Point(12, 212);
            this.lstEvents.MultiSelect = false;
            this.lstEvents.Name = "lstEvents";
            this.lstEvents.Size = new System.Drawing.Size(746, 309);
            this.lstEvents.TabIndex = 68;
            this.lstEvents.UseCompatibleStateImageBehavior = false;
            this.lstEvents.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Time";
            this.columnHeader1.Width = 110;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Direction";
            this.columnHeader5.Width = 80;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Data";
            this.columnHeader6.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Description";
            this.columnHeader3.Width = 400;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnCmd04);
            this.tabPage1.Controls.Add(this.btnCmd03);
            this.tabPage1.Controls.Add(this.btnCmd02);
            this.tabPage1.Controls.Add(this.btnCmd01);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(520, 172);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General commands";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnCmd03
            // 
            this.btnCmd03.Location = new System.Drawing.Point(23, 93);
            this.btnCmd03.Name = "btnCmd03";
            this.btnCmd03.Size = new System.Drawing.Size(206, 25);
            this.btnCmd03.TabIndex = 5;
            this.btnCmd03.Text = "0x03 Module type request";
            this.btnCmd03.UseVisualStyleBackColor = true;
            this.btnCmd03.Click += new System.EventHandler(this.btnCmd03_Click);
            // 
            // btnCmd02
            // 
            this.btnCmd02.Location = new System.Drawing.Point(23, 58);
            this.btnCmd02.Name = "btnCmd02";
            this.btnCmd02.Size = new System.Drawing.Size(206, 25);
            this.btnCmd02.TabIndex = 4;
            this.btnCmd02.Text = "0x02 Reboot";
            this.btnCmd02.UseVisualStyleBackColor = true;
            this.btnCmd02.Click += new System.EventHandler(this.btnCmd02_Click);
            // 
            // btnCmd01
            // 
            this.btnCmd01.Location = new System.Drawing.Point(23, 23);
            this.btnCmd01.Name = "btnCmd01";
            this.btnCmd01.Size = new System.Drawing.Size(206, 25);
            this.btnCmd01.TabIndex = 3;
            this.btnCmd01.Text = "0x01 Check connection";
            this.btnCmd01.UseVisualStyleBackColor = true;
            this.btnCmd01.Click += new System.EventHandler(this.btnCmd01_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(230, 8);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(528, 198);
            this.tabControl1.TabIndex = 72;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.cmbCmd20_1);
            this.tabPage2.Controls.Add(this.cmbCmd21_0);
            this.tabPage2.Controls.Add(this.cmbCmd20_0);
            this.tabPage2.Controls.Add(this.nmCmd20_2);
            this.tabPage2.Controls.Add(this.btnCmd21);
            this.tabPage2.Controls.Add(this.btnCmd20);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(520, 172);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Inputs settings";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cmbCmd20_1
            // 
            this.cmbCmd20_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd20_1.FormattingEnabled = true;
            this.cmbCmd20_1.Items.AddRange(new object[] {
            "Off",
            "On"});
            this.cmbCmd20_1.Location = new System.Drawing.Point(291, 48);
            this.cmbCmd20_1.Name = "cmbCmd20_1";
            this.cmbCmd20_1.Size = new System.Drawing.Size(50, 21);
            this.cmbCmd20_1.TabIndex = 16;
            // 
            // cmbCmd21_0
            // 
            this.cmbCmd21_0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd21_0.FormattingEnabled = true;
            this.cmbCmd21_0.Items.AddRange(new object[] {
            "Inp 0",
            "Inp 1",
            "Inp 2",
            "Inp 3",
            "Inp 4",
            "Inp 5",
            "Inp 6",
            "Inp 7",
            "Inp 8",
            "Inp 9",
            "Inp 10",
            "Inp 11",
            "Inp 12",
            "Inp 13",
            "Inp 14",
            "Inp 15"});
            this.cmbCmd21_0.Location = new System.Drawing.Point(222, 90);
            this.cmbCmd21_0.Name = "cmbCmd21_0";
            this.cmbCmd21_0.Size = new System.Drawing.Size(62, 21);
            this.cmbCmd21_0.TabIndex = 15;
            // 
            // cmbCmd20_0
            // 
            this.cmbCmd20_0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd20_0.FormattingEnabled = true;
            this.cmbCmd20_0.Items.AddRange(new object[] {
            "Inp 0",
            "Inp 1",
            "Inp 2",
            "Inp 3",
            "Inp 4",
            "Inp 5",
            "Inp 6",
            "Inp 7",
            "Inp 8",
            "Inp 9",
            "Inp 10",
            "Inp 11",
            "Inp 12",
            "Inp 13",
            "Inp 14",
            "Inp 15"});
            this.cmbCmd20_0.Location = new System.Drawing.Point(222, 48);
            this.cmbCmd20_0.Name = "cmbCmd20_0";
            this.cmbCmd20_0.Size = new System.Drawing.Size(62, 21);
            this.cmbCmd20_0.TabIndex = 14;
            // 
            // nmCmd20_2
            // 
            this.nmCmd20_2.Location = new System.Drawing.Point(438, 49);
            this.nmCmd20_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nmCmd20_2.Name = "nmCmd20_2";
            this.nmCmd20_2.Size = new System.Drawing.Size(49, 20);
            this.nmCmd20_2.TabIndex = 10;
            this.nmCmd20_2.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // btnCmd21
            // 
            this.btnCmd21.Location = new System.Drawing.Point(23, 87);
            this.btnCmd21.Name = "btnCmd21";
            this.btnCmd21.Size = new System.Drawing.Size(182, 25);
            this.btnCmd21.TabIndex = 8;
            this.btnCmd21.Text = "0x21 Input settings request";
            this.btnCmd21.UseVisualStyleBackColor = true;
            this.btnCmd21.Click += new System.EventHandler(this.btnCmd21_Click);
            // 
            // btnCmd20
            // 
            this.btnCmd20.Location = new System.Drawing.Point(23, 45);
            this.btnCmd20.Name = "btnCmd20";
            this.btnCmd20.Size = new System.Drawing.Size(182, 25);
            this.btnCmd20.TabIndex = 7;
            this.btnCmd20.Text = "0x20 Set input settings";
            this.btnCmd20.UseVisualStyleBackColor = true;
            this.btnCmd20.Click += new System.EventHandler(this.btnCmd20_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.picRel15);
            this.tabPage3.Controls.Add(this.picRel14);
            this.tabPage3.Controls.Add(this.picRel13);
            this.tabPage3.Controls.Add(this.picRel12);
            this.tabPage3.Controls.Add(this.picInp15);
            this.tabPage3.Controls.Add(this.picInp14);
            this.tabPage3.Controls.Add(this.picInp13);
            this.tabPage3.Controls.Add(this.picInp12);
            this.tabPage3.Controls.Add(this.picRel11);
            this.tabPage3.Controls.Add(this.picRel10);
            this.tabPage3.Controls.Add(this.picRel09);
            this.tabPage3.Controls.Add(this.picRel08);
            this.tabPage3.Controls.Add(this.picInp11);
            this.tabPage3.Controls.Add(this.picInp10);
            this.tabPage3.Controls.Add(this.picInp09);
            this.tabPage3.Controls.Add(this.picInp08);
            this.tabPage3.Controls.Add(this.picRel07);
            this.tabPage3.Controls.Add(this.picRel06);
            this.tabPage3.Controls.Add(this.picRel05);
            this.tabPage3.Controls.Add(this.picRel04);
            this.tabPage3.Controls.Add(this.picInp07);
            this.tabPage3.Controls.Add(this.picInp06);
            this.tabPage3.Controls.Add(this.picInp05);
            this.tabPage3.Controls.Add(this.picInp04);
            this.tabPage3.Controls.Add(this.picRel03);
            this.tabPage3.Controls.Add(this.picRel02);
            this.tabPage3.Controls.Add(this.picRel01);
            this.tabPage3.Controls.Add(this.picRel00);
            this.tabPage3.Controls.Add(this.picInp03);
            this.tabPage3.Controls.Add(this.picInp02);
            this.tabPage3.Controls.Add(this.picInp01);
            this.tabPage3.Controls.Add(this.picInp00);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.chkRel15);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.chkRel14);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.chkRel13);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.chkRel12);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.chkRel11);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.chkRel10);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.chkRel09);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.chkRel08);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.chkRel07);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.chkRel06);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.chkRel05);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.chkRel04);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.chkRel03);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.chkRel02);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.chkRel01);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.chkRel00);
            this.tabPage3.Controls.Add(this.btnCmd25);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.cmbCmd22_1);
            this.tabPage3.Controls.Add(this.cmbCmd22_0);
            this.tabPage3.Controls.Add(this.nmCmd22_2);
            this.tabPage3.Controls.Add(this.btnCmd23);
            this.tabPage3.Controls.Add(this.btnCmd22);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(520, 172);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Operations";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(499, 55);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(15, 12);
            this.label26.TabIndex = 105;
            this.label26.Text = "15";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(272, 55);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(10, 12);
            this.label25.TabIndex = 104;
            this.label25.Text = "0";
            // 
            // picRel15
            // 
            this.picRel15.BackColor = System.Drawing.Color.DarkGray;
            this.picRel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel15.InitialImage = null;
            this.picRel15.Location = new System.Drawing.Point(502, 82);
            this.picRel15.Name = "picRel15";
            this.picRel15.Size = new System.Drawing.Size(8, 8);
            this.picRel15.TabIndex = 103;
            this.picRel15.TabStop = false;
            // 
            // picRel14
            // 
            this.picRel14.BackColor = System.Drawing.Color.DarkGray;
            this.picRel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel14.InitialImage = null;
            this.picRel14.Location = new System.Drawing.Point(488, 82);
            this.picRel14.Name = "picRel14";
            this.picRel14.Size = new System.Drawing.Size(8, 8);
            this.picRel14.TabIndex = 102;
            this.picRel14.TabStop = false;
            // 
            // picRel13
            // 
            this.picRel13.BackColor = System.Drawing.Color.DarkGray;
            this.picRel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel13.InitialImage = null;
            this.picRel13.Location = new System.Drawing.Point(474, 82);
            this.picRel13.Name = "picRel13";
            this.picRel13.Size = new System.Drawing.Size(8, 8);
            this.picRel13.TabIndex = 101;
            this.picRel13.TabStop = false;
            // 
            // picRel12
            // 
            this.picRel12.BackColor = System.Drawing.Color.DarkGray;
            this.picRel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel12.InitialImage = null;
            this.picRel12.Location = new System.Drawing.Point(460, 82);
            this.picRel12.Name = "picRel12";
            this.picRel12.Size = new System.Drawing.Size(8, 8);
            this.picRel12.TabIndex = 100;
            this.picRel12.TabStop = false;
            // 
            // picInp15
            // 
            this.picInp15.BackColor = System.Drawing.Color.DarkGray;
            this.picInp15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp15.InitialImage = null;
            this.picInp15.Location = new System.Drawing.Point(502, 67);
            this.picInp15.Name = "picInp15";
            this.picInp15.Size = new System.Drawing.Size(8, 8);
            this.picInp15.TabIndex = 99;
            this.picInp15.TabStop = false;
            // 
            // picInp14
            // 
            this.picInp14.BackColor = System.Drawing.Color.DarkGray;
            this.picInp14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp14.InitialImage = null;
            this.picInp14.Location = new System.Drawing.Point(488, 67);
            this.picInp14.Name = "picInp14";
            this.picInp14.Size = new System.Drawing.Size(8, 8);
            this.picInp14.TabIndex = 98;
            this.picInp14.TabStop = false;
            // 
            // picInp13
            // 
            this.picInp13.BackColor = System.Drawing.Color.DarkGray;
            this.picInp13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp13.InitialImage = null;
            this.picInp13.Location = new System.Drawing.Point(474, 67);
            this.picInp13.Name = "picInp13";
            this.picInp13.Size = new System.Drawing.Size(8, 8);
            this.picInp13.TabIndex = 97;
            this.picInp13.TabStop = false;
            // 
            // picInp12
            // 
            this.picInp12.BackColor = System.Drawing.Color.DarkGray;
            this.picInp12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp12.InitialImage = null;
            this.picInp12.Location = new System.Drawing.Point(460, 67);
            this.picInp12.Name = "picInp12";
            this.picInp12.Size = new System.Drawing.Size(8, 8);
            this.picInp12.TabIndex = 96;
            this.picInp12.TabStop = false;
            // 
            // picRel11
            // 
            this.picRel11.BackColor = System.Drawing.Color.DarkGray;
            this.picRel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel11.InitialImage = null;
            this.picRel11.Location = new System.Drawing.Point(440, 82);
            this.picRel11.Name = "picRel11";
            this.picRel11.Size = new System.Drawing.Size(8, 8);
            this.picRel11.TabIndex = 95;
            this.picRel11.TabStop = false;
            // 
            // picRel10
            // 
            this.picRel10.BackColor = System.Drawing.Color.DarkGray;
            this.picRel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel10.InitialImage = null;
            this.picRel10.Location = new System.Drawing.Point(426, 82);
            this.picRel10.Name = "picRel10";
            this.picRel10.Size = new System.Drawing.Size(8, 8);
            this.picRel10.TabIndex = 94;
            this.picRel10.TabStop = false;
            // 
            // picRel09
            // 
            this.picRel09.BackColor = System.Drawing.Color.DarkGray;
            this.picRel09.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel09.InitialImage = null;
            this.picRel09.Location = new System.Drawing.Point(412, 82);
            this.picRel09.Name = "picRel09";
            this.picRel09.Size = new System.Drawing.Size(8, 8);
            this.picRel09.TabIndex = 93;
            this.picRel09.TabStop = false;
            // 
            // picRel08
            // 
            this.picRel08.BackColor = System.Drawing.Color.DarkGray;
            this.picRel08.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel08.InitialImage = null;
            this.picRel08.Location = new System.Drawing.Point(398, 82);
            this.picRel08.Name = "picRel08";
            this.picRel08.Size = new System.Drawing.Size(8, 8);
            this.picRel08.TabIndex = 92;
            this.picRel08.TabStop = false;
            // 
            // picInp11
            // 
            this.picInp11.BackColor = System.Drawing.Color.DarkGray;
            this.picInp11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp11.InitialImage = null;
            this.picInp11.Location = new System.Drawing.Point(440, 67);
            this.picInp11.Name = "picInp11";
            this.picInp11.Size = new System.Drawing.Size(8, 8);
            this.picInp11.TabIndex = 91;
            this.picInp11.TabStop = false;
            // 
            // picInp10
            // 
            this.picInp10.BackColor = System.Drawing.Color.DarkGray;
            this.picInp10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp10.InitialImage = null;
            this.picInp10.Location = new System.Drawing.Point(426, 67);
            this.picInp10.Name = "picInp10";
            this.picInp10.Size = new System.Drawing.Size(8, 8);
            this.picInp10.TabIndex = 90;
            this.picInp10.TabStop = false;
            // 
            // picInp09
            // 
            this.picInp09.BackColor = System.Drawing.Color.DarkGray;
            this.picInp09.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp09.InitialImage = null;
            this.picInp09.Location = new System.Drawing.Point(412, 67);
            this.picInp09.Name = "picInp09";
            this.picInp09.Size = new System.Drawing.Size(8, 8);
            this.picInp09.TabIndex = 89;
            this.picInp09.TabStop = false;
            // 
            // picInp08
            // 
            this.picInp08.BackColor = System.Drawing.Color.DarkGray;
            this.picInp08.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp08.InitialImage = null;
            this.picInp08.Location = new System.Drawing.Point(398, 67);
            this.picInp08.Name = "picInp08";
            this.picInp08.Size = new System.Drawing.Size(8, 8);
            this.picInp08.TabIndex = 88;
            this.picInp08.TabStop = false;
            // 
            // picRel07
            // 
            this.picRel07.BackColor = System.Drawing.Color.DarkGray;
            this.picRel07.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel07.InitialImage = null;
            this.picRel07.Location = new System.Drawing.Point(377, 82);
            this.picRel07.Name = "picRel07";
            this.picRel07.Size = new System.Drawing.Size(8, 8);
            this.picRel07.TabIndex = 87;
            this.picRel07.TabStop = false;
            // 
            // picRel06
            // 
            this.picRel06.BackColor = System.Drawing.Color.DarkGray;
            this.picRel06.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel06.InitialImage = null;
            this.picRel06.Location = new System.Drawing.Point(363, 82);
            this.picRel06.Name = "picRel06";
            this.picRel06.Size = new System.Drawing.Size(8, 8);
            this.picRel06.TabIndex = 86;
            this.picRel06.TabStop = false;
            // 
            // picRel05
            // 
            this.picRel05.BackColor = System.Drawing.Color.DarkGray;
            this.picRel05.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel05.InitialImage = null;
            this.picRel05.Location = new System.Drawing.Point(349, 82);
            this.picRel05.Name = "picRel05";
            this.picRel05.Size = new System.Drawing.Size(8, 8);
            this.picRel05.TabIndex = 85;
            this.picRel05.TabStop = false;
            // 
            // picRel04
            // 
            this.picRel04.BackColor = System.Drawing.Color.DarkGray;
            this.picRel04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel04.InitialImage = null;
            this.picRel04.Location = new System.Drawing.Point(335, 82);
            this.picRel04.Name = "picRel04";
            this.picRel04.Size = new System.Drawing.Size(8, 8);
            this.picRel04.TabIndex = 84;
            this.picRel04.TabStop = false;
            // 
            // picInp07
            // 
            this.picInp07.BackColor = System.Drawing.Color.DarkGray;
            this.picInp07.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp07.InitialImage = null;
            this.picInp07.Location = new System.Drawing.Point(377, 67);
            this.picInp07.Name = "picInp07";
            this.picInp07.Size = new System.Drawing.Size(8, 8);
            this.picInp07.TabIndex = 83;
            this.picInp07.TabStop = false;
            // 
            // picInp06
            // 
            this.picInp06.BackColor = System.Drawing.Color.DarkGray;
            this.picInp06.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp06.InitialImage = null;
            this.picInp06.Location = new System.Drawing.Point(363, 67);
            this.picInp06.Name = "picInp06";
            this.picInp06.Size = new System.Drawing.Size(8, 8);
            this.picInp06.TabIndex = 82;
            this.picInp06.TabStop = false;
            // 
            // picInp05
            // 
            this.picInp05.BackColor = System.Drawing.Color.DarkGray;
            this.picInp05.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp05.InitialImage = null;
            this.picInp05.Location = new System.Drawing.Point(349, 67);
            this.picInp05.Name = "picInp05";
            this.picInp05.Size = new System.Drawing.Size(8, 8);
            this.picInp05.TabIndex = 81;
            this.picInp05.TabStop = false;
            // 
            // picInp04
            // 
            this.picInp04.BackColor = System.Drawing.Color.DarkGray;
            this.picInp04.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp04.InitialImage = null;
            this.picInp04.Location = new System.Drawing.Point(335, 67);
            this.picInp04.Name = "picInp04";
            this.picInp04.Size = new System.Drawing.Size(8, 8);
            this.picInp04.TabIndex = 80;
            this.picInp04.TabStop = false;
            // 
            // picRel03
            // 
            this.picRel03.BackColor = System.Drawing.Color.DarkGray;
            this.picRel03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel03.InitialImage = null;
            this.picRel03.Location = new System.Drawing.Point(315, 82);
            this.picRel03.Name = "picRel03";
            this.picRel03.Size = new System.Drawing.Size(8, 8);
            this.picRel03.TabIndex = 79;
            this.picRel03.TabStop = false;
            // 
            // picRel02
            // 
            this.picRel02.BackColor = System.Drawing.Color.DarkGray;
            this.picRel02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel02.InitialImage = null;
            this.picRel02.Location = new System.Drawing.Point(301, 82);
            this.picRel02.Name = "picRel02";
            this.picRel02.Size = new System.Drawing.Size(8, 8);
            this.picRel02.TabIndex = 78;
            this.picRel02.TabStop = false;
            // 
            // picRel01
            // 
            this.picRel01.BackColor = System.Drawing.Color.DarkGray;
            this.picRel01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel01.InitialImage = null;
            this.picRel01.Location = new System.Drawing.Point(287, 82);
            this.picRel01.Name = "picRel01";
            this.picRel01.Size = new System.Drawing.Size(8, 8);
            this.picRel01.TabIndex = 77;
            this.picRel01.TabStop = false;
            // 
            // picRel00
            // 
            this.picRel00.BackColor = System.Drawing.Color.DarkGray;
            this.picRel00.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picRel00.InitialImage = null;
            this.picRel00.Location = new System.Drawing.Point(273, 82);
            this.picRel00.Name = "picRel00";
            this.picRel00.Size = new System.Drawing.Size(8, 8);
            this.picRel00.TabIndex = 76;
            this.picRel00.TabStop = false;
            // 
            // picInp03
            // 
            this.picInp03.BackColor = System.Drawing.Color.DarkGray;
            this.picInp03.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp03.InitialImage = null;
            this.picInp03.Location = new System.Drawing.Point(315, 67);
            this.picInp03.Name = "picInp03";
            this.picInp03.Size = new System.Drawing.Size(8, 8);
            this.picInp03.TabIndex = 71;
            this.picInp03.TabStop = false;
            // 
            // picInp02
            // 
            this.picInp02.BackColor = System.Drawing.Color.DarkGray;
            this.picInp02.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp02.InitialImage = null;
            this.picInp02.Location = new System.Drawing.Point(301, 67);
            this.picInp02.Name = "picInp02";
            this.picInp02.Size = new System.Drawing.Size(8, 8);
            this.picInp02.TabIndex = 70;
            this.picInp02.TabStop = false;
            // 
            // picInp01
            // 
            this.picInp01.BackColor = System.Drawing.Color.DarkGray;
            this.picInp01.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp01.InitialImage = null;
            this.picInp01.Location = new System.Drawing.Point(287, 67);
            this.picInp01.Name = "picInp01";
            this.picInp01.Size = new System.Drawing.Size(8, 8);
            this.picInp01.TabIndex = 69;
            this.picInp01.TabStop = false;
            // 
            // picInp00
            // 
            this.picInp00.BackColor = System.Drawing.Color.DarkGray;
            this.picInp00.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.picInp00.InitialImage = null;
            this.picInp00.Location = new System.Drawing.Point(273, 67);
            this.picInp00.Name = "picInp00";
            this.picInp00.Size = new System.Drawing.Size(8, 8);
            this.picInp00.TabIndex = 68;
            this.picInp00.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(228, 79);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(39, 13);
            this.label24.TabIndex = 67;
            this.label24.Text = "Relays";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(228, 64);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 13);
            this.label23.TabIndex = 66;
            this.label23.Text = "Inputs";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(463, 134);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 12);
            this.label15.TabIndex = 65;
            this.label15.Text = "15";
            // 
            // chkRel15
            // 
            this.chkRel15.AutoSize = true;
            this.chkRel15.Location = new System.Drawing.Point(464, 147);
            this.chkRel15.Name = "chkRel15";
            this.chkRel15.Size = new System.Drawing.Size(15, 14);
            this.chkRel15.TabIndex = 64;
            this.chkRel15.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(431, 134);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 12);
            this.label16.TabIndex = 63;
            this.label16.Text = "14";
            // 
            // chkRel14
            // 
            this.chkRel14.AutoSize = true;
            this.chkRel14.Location = new System.Drawing.Point(432, 147);
            this.chkRel14.Name = "chkRel14";
            this.chkRel14.Size = new System.Drawing.Size(15, 14);
            this.chkRel14.TabIndex = 62;
            this.chkRel14.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(399, 134);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 12);
            this.label17.TabIndex = 61;
            this.label17.Text = "13";
            // 
            // chkRel13
            // 
            this.chkRel13.AutoSize = true;
            this.chkRel13.Location = new System.Drawing.Point(400, 147);
            this.chkRel13.Name = "chkRel13";
            this.chkRel13.Size = new System.Drawing.Size(15, 14);
            this.chkRel13.TabIndex = 60;
            this.chkRel13.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(367, 134);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 12);
            this.label18.TabIndex = 59;
            this.label18.Text = "12";
            // 
            // chkRel12
            // 
            this.chkRel12.AutoSize = true;
            this.chkRel12.Location = new System.Drawing.Point(368, 147);
            this.chkRel12.Name = "chkRel12";
            this.chkRel12.Size = new System.Drawing.Size(15, 14);
            this.chkRel12.TabIndex = 58;
            this.chkRel12.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(335, 134);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 12);
            this.label19.TabIndex = 57;
            this.label19.Text = "11";
            // 
            // chkRel11
            // 
            this.chkRel11.AutoSize = true;
            this.chkRel11.Location = new System.Drawing.Point(336, 147);
            this.chkRel11.Name = "chkRel11";
            this.chkRel11.Size = new System.Drawing.Size(15, 14);
            this.chkRel11.TabIndex = 56;
            this.chkRel11.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(303, 134);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 12);
            this.label20.TabIndex = 55;
            this.label20.Text = "10";
            // 
            // chkRel10
            // 
            this.chkRel10.AutoSize = true;
            this.chkRel10.Location = new System.Drawing.Point(304, 147);
            this.chkRel10.Name = "chkRel10";
            this.chkRel10.Size = new System.Drawing.Size(15, 14);
            this.chkRel10.TabIndex = 54;
            this.chkRel10.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(274, 134);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(10, 12);
            this.label21.TabIndex = 53;
            this.label21.Text = "9";
            // 
            // chkRel09
            // 
            this.chkRel09.AutoSize = true;
            this.chkRel09.Location = new System.Drawing.Point(272, 147);
            this.chkRel09.Name = "chkRel09";
            this.chkRel09.Size = new System.Drawing.Size(15, 14);
            this.chkRel09.TabIndex = 52;
            this.chkRel09.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(242, 134);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(10, 12);
            this.label22.TabIndex = 51;
            this.label22.Text = "8";
            // 
            // chkRel08
            // 
            this.chkRel08.AutoSize = true;
            this.chkRel08.Location = new System.Drawing.Point(240, 147);
            this.chkRel08.Name = "chkRel08";
            this.chkRel08.Size = new System.Drawing.Size(15, 14);
            this.chkRel08.TabIndex = 50;
            this.chkRel08.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(466, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(10, 12);
            this.label11.TabIndex = 49;
            this.label11.Text = "7";
            // 
            // chkRel07
            // 
            this.chkRel07.AutoSize = true;
            this.chkRel07.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chkRel07.Location = new System.Drawing.Point(464, 118);
            this.chkRel07.Name = "chkRel07";
            this.chkRel07.Size = new System.Drawing.Size(15, 14);
            this.chkRel07.TabIndex = 48;
            this.chkRel07.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(434, 105);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 12);
            this.label12.TabIndex = 47;
            this.label12.Text = "6";
            // 
            // chkRel06
            // 
            this.chkRel06.AutoSize = true;
            this.chkRel06.Location = new System.Drawing.Point(432, 118);
            this.chkRel06.Name = "chkRel06";
            this.chkRel06.Size = new System.Drawing.Size(15, 14);
            this.chkRel06.TabIndex = 46;
            this.chkRel06.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(402, 105);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(10, 12);
            this.label13.TabIndex = 45;
            this.label13.Text = "5";
            // 
            // chkRel05
            // 
            this.chkRel05.AutoSize = true;
            this.chkRel05.Location = new System.Drawing.Point(400, 118);
            this.chkRel05.Name = "chkRel05";
            this.chkRel05.Size = new System.Drawing.Size(15, 14);
            this.chkRel05.TabIndex = 44;
            this.chkRel05.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(370, 105);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(10, 12);
            this.label14.TabIndex = 43;
            this.label14.Text = "4";
            // 
            // chkRel04
            // 
            this.chkRel04.AutoSize = true;
            this.chkRel04.Location = new System.Drawing.Point(368, 118);
            this.chkRel04.Name = "chkRel04";
            this.chkRel04.Size = new System.Drawing.Size(15, 14);
            this.chkRel04.TabIndex = 42;
            this.chkRel04.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(338, 105);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 12);
            this.label9.TabIndex = 41;
            this.label9.Text = "3";
            // 
            // chkRel03
            // 
            this.chkRel03.AutoSize = true;
            this.chkRel03.Location = new System.Drawing.Point(336, 118);
            this.chkRel03.Name = "chkRel03";
            this.chkRel03.Size = new System.Drawing.Size(15, 14);
            this.chkRel03.TabIndex = 40;
            this.chkRel03.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(306, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(10, 12);
            this.label10.TabIndex = 39;
            this.label10.Text = "2";
            // 
            // chkRel02
            // 
            this.chkRel02.AutoSize = true;
            this.chkRel02.Location = new System.Drawing.Point(304, 118);
            this.chkRel02.Name = "chkRel02";
            this.chkRel02.Size = new System.Drawing.Size(15, 14);
            this.chkRel02.TabIndex = 38;
            this.chkRel02.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(274, 105);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 12);
            this.label8.TabIndex = 37;
            this.label8.Text = "1";
            // 
            // chkRel01
            // 
            this.chkRel01.AutoSize = true;
            this.chkRel01.Location = new System.Drawing.Point(272, 118);
            this.chkRel01.Name = "chkRel01";
            this.chkRel01.Size = new System.Drawing.Size(15, 14);
            this.chkRel01.TabIndex = 36;
            this.chkRel01.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(242, 105);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 12);
            this.label7.TabIndex = 35;
            this.label7.Text = "0";
            // 
            // chkRel00
            // 
            this.chkRel00.AutoSize = true;
            this.chkRel00.Location = new System.Drawing.Point(240, 118);
            this.chkRel00.Name = "chkRel00";
            this.chkRel00.Size = new System.Drawing.Size(15, 14);
            this.chkRel00.TabIndex = 34;
            this.chkRel00.UseVisualStyleBackColor = true;
            // 
            // btnCmd25
            // 
            this.btnCmd25.Location = new System.Drawing.Point(13, 109);
            this.btnCmd25.Name = "btnCmd25";
            this.btnCmd25.Size = new System.Drawing.Size(206, 25);
            this.btnCmd25.TabIndex = 33;
            this.btnCmd25.Text = "0x25 Relay Group On/Off";
            this.btnCmd25.UseVisualStyleBackColor = true;
            this.btnCmd25.Click += new System.EventHandler(this.btnCmd25_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(418, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 14);
            this.label5.TabIndex = 32;
            this.label5.Text = "0-255";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(464, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "*100ms";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(351, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 30;
            this.label3.Text = "Turn On for";
            // 
            // cmbCmd22_1
            // 
            this.cmbCmd22_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd22_1.FormattingEnabled = true;
            this.cmbCmd22_1.Items.AddRange(new object[] {
            "Off",
            "On"});
            this.cmbCmd22_1.Location = new System.Drawing.Point(298, 26);
            this.cmbCmd22_1.Name = "cmbCmd22_1";
            this.cmbCmd22_1.Size = new System.Drawing.Size(50, 21);
            this.cmbCmd22_1.TabIndex = 29;
            // 
            // cmbCmd22_0
            // 
            this.cmbCmd22_0.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCmd22_0.FormattingEnabled = true;
            this.cmbCmd22_0.Items.AddRange(new object[] {
            "Relay 0",
            "Relay 1",
            "Relay 2",
            "Relay 3",
            "Relay 4",
            "Relay 5",
            "Relay 6",
            "Relay 7",
            "Relay 8",
            "Relay 9",
            "Relay 10",
            "Relay 11",
            "Relay 12",
            "Relay 13",
            "Relay 14",
            "Relay 15"});
            this.cmbCmd22_0.Location = new System.Drawing.Point(225, 26);
            this.cmbCmd22_0.Name = "cmbCmd22_0";
            this.cmbCmd22_0.Size = new System.Drawing.Size(67, 21);
            this.cmbCmd22_0.TabIndex = 28;
            // 
            // nmCmd22_2
            // 
            this.nmCmd22_2.Location = new System.Drawing.Point(414, 27);
            this.nmCmd22_2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nmCmd22_2.Name = "nmCmd22_2";
            this.nmCmd22_2.Size = new System.Drawing.Size(49, 20);
            this.nmCmd22_2.TabIndex = 27;
            // 
            // btnCmd23
            // 
            this.btnCmd23.Location = new System.Drawing.Point(13, 65);
            this.btnCmd23.Name = "btnCmd23";
            this.btnCmd23.Size = new System.Drawing.Size(206, 25);
            this.btnCmd23.TabIndex = 26;
            this.btnCmd23.Text = "0x23 Inputs and Relays state request";
            this.btnCmd23.UseVisualStyleBackColor = true;
            this.btnCmd23.Click += new System.EventHandler(this.btnCmd23_Click);
            // 
            // btnCmd22
            // 
            this.btnCmd22.Location = new System.Drawing.Point(13, 23);
            this.btnCmd22.Name = "btnCmd22";
            this.btnCmd22.Size = new System.Drawing.Size(206, 25);
            this.btnCmd22.TabIndex = 25;
            this.btnCmd22.Text = "0x22 Relay On/Off";
            this.btnCmd22.UseVisualStyleBackColor = true;
            this.btnCmd22.Click += new System.EventHandler(this.btnCmd22_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 533);
            this.Controls.Add(this.labelURL);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lstEvents);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "\"Socket-Giant\" Control and Testing";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picConState)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmCmd20_2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRel00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInp00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmCmd22_2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imgListConnection;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelURL;
        private System.Windows.Forms.ImageList imgListDirection;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblConState;
        private System.Windows.Forms.PictureBox picConState;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox txtIPaddress;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtIPport;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer tmrConState;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCmd04;
        private System.Windows.Forms.ListView lstEvents;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnCmd03;
        private System.Windows.Forms.Button btnCmd02;
        private System.Windows.Forms.Button btnCmd01;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cmbCmd20_1;
        private System.Windows.Forms.ComboBox cmbCmd21_0;
        private System.Windows.Forms.ComboBox cmbCmd20_0;
        private System.Windows.Forms.NumericUpDown nmCmd20_2;
        private System.Windows.Forms.Button btnCmd21;
        private System.Windows.Forms.Button btnCmd20;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnCmd25;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbCmd22_1;
        private System.Windows.Forms.ComboBox cmbCmd22_0;
        private System.Windows.Forms.NumericUpDown nmCmd22_2;
        private System.Windows.Forms.Button btnCmd23;
        private System.Windows.Forms.Button btnCmd22;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkRel15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox chkRel14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chkRel13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox chkRel12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox chkRel11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox chkRel10;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox chkRel09;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox chkRel08;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox chkRel07;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox chkRel06;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox chkRel05;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chkRel04;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkRel03;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkRel02;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkRel01;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chkRel00;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox picRel15;
        private System.Windows.Forms.PictureBox picRel14;
        private System.Windows.Forms.PictureBox picRel13;
        private System.Windows.Forms.PictureBox picRel12;
        private System.Windows.Forms.PictureBox picInp15;
        private System.Windows.Forms.PictureBox picInp14;
        private System.Windows.Forms.PictureBox picInp13;
        private System.Windows.Forms.PictureBox picInp12;
        private System.Windows.Forms.PictureBox picRel11;
        private System.Windows.Forms.PictureBox picRel10;
        private System.Windows.Forms.PictureBox picRel09;
        private System.Windows.Forms.PictureBox picRel08;
        private System.Windows.Forms.PictureBox picInp11;
        private System.Windows.Forms.PictureBox picInp10;
        private System.Windows.Forms.PictureBox picInp09;
        private System.Windows.Forms.PictureBox picInp08;
        private System.Windows.Forms.PictureBox picRel07;
        private System.Windows.Forms.PictureBox picRel06;
        private System.Windows.Forms.PictureBox picRel05;
        private System.Windows.Forms.PictureBox picRel04;
        private System.Windows.Forms.PictureBox picInp07;
        private System.Windows.Forms.PictureBox picInp06;
        private System.Windows.Forms.PictureBox picInp05;
        private System.Windows.Forms.PictureBox picInp04;
        private System.Windows.Forms.PictureBox picRel03;
        private System.Windows.Forms.PictureBox picRel02;
        private System.Windows.Forms.PictureBox picRel01;
        private System.Windows.Forms.PictureBox picRel00;
        private System.Windows.Forms.PictureBox picInp03;
        private System.Windows.Forms.PictureBox picInp02;
        private System.Windows.Forms.PictureBox picInp01;
        private System.Windows.Forms.PictureBox picInp00;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
    }
}

