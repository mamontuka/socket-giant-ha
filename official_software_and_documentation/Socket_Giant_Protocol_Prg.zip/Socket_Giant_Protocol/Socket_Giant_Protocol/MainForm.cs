﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;


namespace Socket_Giant_Protocol
{
    public partial class MainForm : Form
    {
        // delegate to access the ListView component from the socket polling thread
        public delegate void listViewUpdateCallBack(string param1, string param2, string param3, string param4);

        System.Net.Sockets.TcpClient clientSocket = new System.Net.Sockets.TcpClient();
        // read-write stream
        NetworkStream serverStream = default(NetworkStream);
        Thread ctThread;
        string patternIP;       // regular expression to check if the entered IP address is correct


        public MainForm()
        {
            InitializeComponent();
            patternIP = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor = Cursors.AppStarting;
                cmbCmd20_0.SelectedIndex = 0;
                cmbCmd20_1.SelectedIndex = 0;
                cmbCmd21_0.SelectedIndex = 0;
                cmbCmd22_0.SelectedIndex = 0;
                cmbCmd22_1.SelectedIndex = 0;

                Cursor = Cursors.Default;
            }
            catch (Exception er)
            {
                Cursor = Cursors.Default;
                MessageBox.Show(er.Message);
                Application.Exit();
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clientSocket.Connected)
            {
                ctThread.Abort();
                clientSocket.Client.Disconnect(true);
            }
        }




        // listview control update function
        public void listViewUpdate(string param1, string param2, string param3, string param4)
        {
            try
            {
                if (this.lstEvents.InvokeRequired)  // if the component is called from another thread
                {
                    listViewUpdateCallBack d = new listViewUpdateCallBack(listViewUpdate);  // create a delegate
                    this.Invoke(d, new object[] { param1, param2, param3, param4 });
                }
                else    // otherwise update the component
                {
                    this.lstEvents.Items.Add(param1);
                    this.lstEvents.Items[lstEvents.Items.Count - 1].SubItems.Add(param2);
                    this.lstEvents.Items[lstEvents.Items.Count - 1].SubItems.Add(param3);
                    this.lstEvents.Items[lstEvents.Items.Count - 1].SubItems.Add(param4);
                    this.lstEvents.Items[lstEvents.Items.Count - 1].ImageIndex = 1;
                    this.lstEvents.EnsureVisible(lstEvents.Items.Count - 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
        // byte to hexadecimal string conversion function
        private String ByteToHex(Byte BT)
        {
            Int32 iTmpH = BT / (Byte)16;
            Int32 iTmpL = BT % (Byte)16;
            String ret = "";

            if (iTmpH == 0) ret = "0";
            if (iTmpH == 1) ret = "1";
            if (iTmpH == 2) ret = "2";
            if (iTmpH == 3) ret = "3";
            if (iTmpH == 4) ret = "4";
            if (iTmpH == 5) ret = "5";
            if (iTmpH == 6) ret = "6";
            if (iTmpH == 7) ret = "7";
            if (iTmpH == 8) ret = "8";
            if (iTmpH == 9) ret = "9";
            if (iTmpH == 10) ret = "A";
            if (iTmpH == 11) ret = "B";
            if (iTmpH == 12) ret = "C";
            if (iTmpH == 13) ret = "D";
            if (iTmpH == 14) ret = "E";
            if (iTmpH == 15) ret = "F";

            if (iTmpL == 0) ret += "0";
            if (iTmpL == 1) ret += "1";
            if (iTmpL == 2) ret += "2";
            if (iTmpL == 3) ret += "3";
            if (iTmpL == 4) ret += "4";
            if (iTmpL == 5) ret += "5";
            if (iTmpL == 6) ret += "6";
            if (iTmpL == 7) ret += "7";
            if (iTmpL == 8) ret += "8";
            if (iTmpL == 9) ret += "9";
            if (iTmpL == 10) ret += "A";
            if (iTmpL == 11) ret += "B";
            if (iTmpL == 12) ret += "C";
            if (iTmpL == 13) ret += "D";
            if (iTmpL == 14) ret += "E";
            if (iTmpL == 15) ret += "F";

            return ret;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //	COMMANDS
        //


        // 0x01 Check connection
        private void btnCmd01_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if the connection is established
                {
                    String message = "";
                    Byte[] mes = new Byte[1];   // a variable that will contain the data to send

                    mes[0] = 0x01;
                    message = "01";     // message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Check connection");

                    serverStream.Write(mes, 0, 1);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x02 Reboot
        private void btnCmd02_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Reboot will result in loss of connection!\r\nDo the reboot?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
                return;
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[1];   //a variable that will contain the data to send

                    mes[0] = 0x02;
                    message = "02";     //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Reboot");

                    serverStream.Write(mes, 0, 1);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x03 Module type request
        private void btnCmd03_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[1];   //a variable that will contain the data to send

                    mes[0] = 0x03;
                    message = "03";     //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Module type request");

                    serverStream.Write(mes, 0, 1);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x04 UID request
        private void btnCmd04_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[1];   //a variable that will contain the data to send

                    mes[0] = 0x04;
                    message = "04";     //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "UID request");

                    serverStream.Write(mes, 0, 1);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }



        // 0x20 Set input settings
        private void btnCmd20_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[4];   //a variable that will contain the data to send

                    mes[0] = 0x20;
                    mes[1] = (byte)cmbCmd20_0.SelectedIndex;
                    mes[2] = (byte)cmbCmd20_1.SelectedIndex;
                    mes[3] = (byte)nmCmd20_2.Value;
                    message = "20 " + ByteToHex(mes[1]) + " " + ByteToHex(mes[2]) + " " + ByteToHex(mes[3]);        //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Set input settings");

                    serverStream.Write(mes, 0, 4);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x21 Input settings request
        private void btnCmd21_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[2];   //a variable that will contain the data to send

                    mes[0] = 0x21;
                    mes[1] = (byte)cmbCmd21_0.SelectedIndex;
                    message = "21 " + ByteToHex(mes[1]);        //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Input settings request");

                    serverStream.Write(mes, 0, 2);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x22 Relay On/Off
        private void btnCmd22_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[4];   //a variable that will contain the data to send

                    mes[0] = 0x22;
                    mes[1] = (byte)cmbCmd22_0.SelectedIndex;
                    mes[2] = (byte)cmbCmd22_1.SelectedIndex;
                    mes[3] = (byte)nmCmd22_2.Value;
                    message = "22 " + ByteToHex(mes[1]) + " " + ByteToHex(mes[2]) + " " + ByteToHex(mes[3]);        //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Relay On/Off");

                    serverStream.Write(mes, 0, 4);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x23 Inputs and Relays state request
        private void btnCmd23_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[1];   //a variable that will contain the data to send

                    mes[0] = 0x23;
                    message = "23";     //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Inputs and Relays state request");

                    serverStream.Write(mes, 0, 1);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        // 0x25 Relay Group On/Off
        private void btnCmd25_Click(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)     // if there is connection
                {
                    String message = "";
                    Byte[] mes = new Byte[3];   //a variable that will contain the data to send

                    mes[0] = 0x25;
                    mes[1] = 0x00;
                    mes[2] = 0x00;
                    if (chkRel15.Checked) mes[1] |= 0x80;
                    if (chkRel14.Checked) mes[1] |= 0x40;
                    if (chkRel13.Checked) mes[1] |= 0x20;
                    if (chkRel12.Checked) mes[1] |= 0x10;
                    if (chkRel11.Checked) mes[1] |= 0x08;
                    if (chkRel10.Checked) mes[1] |= 0x04;
                    if (chkRel09.Checked) mes[1] |= 0x02;
                    if (chkRel08.Checked) mes[1] |= 0x01;
                    if (chkRel07.Checked) mes[2] |= 0x80;
                    if (chkRel06.Checked) mes[2] |= 0x40;
                    if (chkRel05.Checked) mes[2] |= 0x20;
                    if (chkRel04.Checked) mes[2] |= 0x10;
                    if (chkRel03.Checked) mes[2] |= 0x08;
                    if (chkRel02.Checked) mes[2] |= 0x04;
                    if (chkRel01.Checked) mes[2] |= 0x02;
                    if (chkRel00.Checked) mes[2] |= 0x01;
                    message = "25 " + ByteToHex(mes[1]) + " " + ByteToHex(mes[2]);        //message to display in ListView

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "Command", message, "Relay Group On/Off");

                    serverStream.Write(mes, 0, 3);
                    serverStream.Flush();
                }
                else
                {
                    MessageBox.Show("No connection.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }




        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //	RESPONSE RECEPTION FLOW
        //

        private void getMessage()
        {
            while (true)
            {
                if (clientSocket.Connected)
                {
                    serverStream = clientSocket.GetStream();
                    int buffSize = 0;
                    int bytesRead = 0;
                    byte[] inStream = new byte[10025];
                    buffSize = clientSocket.ReceiveBufferSize;
                    try
                    {
                        bytesRead = serverStream.Read(inStream, 0, buffSize);
                    }
                    catch (Exception er)
                    {
                        ;
                    }

                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    // form a string with the date and time the data was received
                    string message = "";

                    // form messages for output in the ListView in hexadecimal form
                    for (int i = 0; i < bytesRead; i++)
                        message = message + ByteToHex(inStream[i]) + " ";

                    // if the data is received - display it in the ListView
                    if (bytesRead > 0)
                    {
                        switch (inStream[0])
                        {
                            case 0x01:
                                listViewUpdate(DT, "Response", message, "Check connection response");
                                break;
                            case 0x03:
                                if (bytesRead >= 2)
                                {
                                    switch (inStream[1])
                                    {
                                        case 1: listViewUpdate(DT, "Response", message, "Module type: VRD-E reader"); break;
                                        case 2: listViewUpdate(DT, "Response", message, "Module typeя: Socket-2"); break;
                                        case 3: listViewUpdate(DT, "Response", message, "Module type: Socket-1"); break;
                                        case 4: listViewUpdate(DT, "Response", message, "Module type: Socket-3"); break;
                                        case 5: listViewUpdate(DT, "Response", message, "Module type: Socket-4"); break;
                                        case 6: listViewUpdate(DT, "Response", message, "Module type: Socket-5"); break;
                                        case 7: listViewUpdate(DT, "Response", message, "Module type: Socket-Giant"); break;
                                    }
                                }
                                else
                                    listViewUpdate(DT, "Response", message, "Module type");
                                break;
                            case 0x04:
                                if (bytesRead >= 3)
                                    listViewUpdate(DT, "Response", message, "Module UID: " + ((int)inStream[1] * 256 + (int)inStream[2]).ToString());
                                else
                                    listViewUpdate(DT, "Response", message, "Module UID");
                                break;
                            case 0x20:
                                listViewUpdate(DT, "Response", message, "Input settings");
                                break;
                            case 0x21:
                                listViewUpdate(DT, "Response", message, "Input state changed");
                                break;
                            case 0x22:
                                listViewUpdate(DT, "Response", message, "Relay On/Off");
                                break;
                            case 0x23:
                                listViewUpdate(DT, "Response", message, "Inputs and Relays state");
                                picInp00.BackColor = picInp01.BackColor = picInp02.BackColor = picInp03.BackColor = picInp04.BackColor = picInp05.BackColor = picInp06.BackColor = picInp07.BackColor =
                                picInp08.BackColor = picInp09.BackColor = picInp10.BackColor = picInp11.BackColor = picInp12.BackColor = picInp13.BackColor = picInp14.BackColor = picInp15.BackColor = Color.DarkGray;
                                picRel00.BackColor = picRel01.BackColor = picRel02.BackColor = picRel03.BackColor = picRel04.BackColor = picRel05.BackColor = picRel06.BackColor = picRel07.BackColor =
                                picRel08.BackColor = picRel09.BackColor = picRel10.BackColor = picRel11.BackColor = picRel12.BackColor = picRel13.BackColor = picRel14.BackColor = picRel15.BackColor = Color.DarkGray;
                                if (bytesRead >= 5)
                                {
                                    if ((inStream[1] & 0x80) > 0) picInp15.BackColor = Color.Red;
                                    if ((inStream[1] & 0x40) > 0) picInp14.BackColor = Color.Red;
                                    if ((inStream[1] & 0x20) > 0) picInp13.BackColor = Color.Red;
                                    if ((inStream[1] & 0x10) > 0) picInp12.BackColor = Color.Red;
                                    if ((inStream[1] & 0x08) > 0) picInp11.BackColor = Color.Red;
                                    if ((inStream[1] & 0x04) > 0) picInp10.BackColor = Color.Red;
                                    if ((inStream[1] & 0x02) > 0) picInp09.BackColor = Color.Red;
                                    if ((inStream[1] & 0x01) > 0) picInp08.BackColor = Color.Red;
                                    if ((inStream[2] & 0x80) > 0) picInp07.BackColor = Color.Red;
                                    if ((inStream[2] & 0x40) > 0) picInp06.BackColor = Color.Red;
                                    if ((inStream[2] & 0x20) > 0) picInp05.BackColor = Color.Red;
                                    if ((inStream[2] & 0x10) > 0) picInp04.BackColor = Color.Red;
                                    if ((inStream[2] & 0x08) > 0) picInp03.BackColor = Color.Red;
                                    if ((inStream[2] & 0x04) > 0) picInp02.BackColor = Color.Red;
                                    if ((inStream[2] & 0x02) > 0) picInp01.BackColor = Color.Red;
                                    if ((inStream[2] & 0x01) > 0) picInp00.BackColor = Color.Red;
                                    if ((inStream[3] & 0x80) > 0) picRel15.BackColor = Color.Red;
                                    if ((inStream[3] & 0x40) > 0) picRel14.BackColor = Color.Red;
                                    if ((inStream[3] & 0x20) > 0) picRel13.BackColor = Color.Red;
                                    if ((inStream[3] & 0x10) > 0) picRel12.BackColor = Color.Red;
                                    if ((inStream[3] & 0x08) > 0) picRel11.BackColor = Color.Red;
                                    if ((inStream[3] & 0x04) > 0) picRel10.BackColor = Color.Red;
                                    if ((inStream[3] & 0x02) > 0) picRel09.BackColor = Color.Red;
                                    if ((inStream[3] & 0x01) > 0) picRel08.BackColor = Color.Red;
                                    if ((inStream[4] & 0x80) > 0) picRel07.BackColor = Color.Red;
                                    if ((inStream[4] & 0x40) > 0) picRel06.BackColor = Color.Red;
                                    if ((inStream[4] & 0x20) > 0) picRel05.BackColor = Color.Red;
                                    if ((inStream[4] & 0x10) > 0) picRel04.BackColor = Color.Red;
                                    if ((inStream[4] & 0x08) > 0) picRel03.BackColor = Color.Red;
                                    if ((inStream[4] & 0x04) > 0) picRel02.BackColor = Color.Red;
                                    if ((inStream[4] & 0x02) > 0) picRel01.BackColor = Color.Red;
                                    if ((inStream[4] & 0x01) > 0) picRel00.BackColor = Color.Red;
                                }
                                break;
                            case 0x25:
                                listViewUpdate(DT, "Response", message, "Relay Group On/Off");
                                break;
                        }
                    }
                }
            }
        }




        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //	OPEN AND CLOSE CONNECTION
        //

        void BtnConnectClick(object sender, EventArgs e)
        {
            try
            {
                int port = Int32.Parse(txtIPport.Text);
                if ((port > 64000) || (port < 20))      // if this is a number and it is not between 20 and 64000 - we display an error message
                {
                    MessageBox.Show("Allowed port number range 20...64000.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                    return;
                }
            }
            catch (Exception ex)
            {
                // if there is not a number in the text field - display an error message
                MessageBox.Show("Incorrect port number." + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                return;
            }

            // check if the IP address is entered correctly in the text field
            Match m = Regex.Match(txtIPaddress.Text, patternIP);
            if (!(m.Success))
            {
                MessageBox.Show("Incorrect IP-address", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                return;
            }

            try
            {
                if (!clientSocket.Connected)
                {

                    clientSocket = new System.Net.Sockets.TcpClient();
                    clientSocket.Connect(txtIPaddress.Text, Int32.Parse(txtIPport.Text));
                    // connect to the IP and port entered in the text fields
                    serverStream = clientSocket.GetStream();
                    // get the stream
                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    // form a string with the date and time at which the connection occurred and add it to the ListView
                    listViewUpdate(DT, "", "", "Connection open");
                    picConState.BackgroundImage = imgListConnection.Images["Conn_Green"];
                    lblConState.Text = "Open";

                    this.lstEvents.EnsureVisible(lstEvents.Items.Count - 1);
                    clientSocket.ReceiveBufferSize = 8192;
                    ctThread = new Thread(getMessage);
                    // create a thread in which data will be received and run it
                    ctThread.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        void BtnDisconnectClick(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)
                {
                    ctThread.Abort();

                    // form a string with the date of shutdown, add it to the ListView and turn off
                    string DT = DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" + DateTime.Now.Second.ToString("00") + "." + DateTime.Now.Millisecond.ToString("000");
                    listViewUpdate(DT, "", "", "Connection closed");
                    picConState.BackgroundImage = imgListConnection.Images["Conn_Red"];
                    lblConState.Text = "Closed";

                    clientSocket.Client.Disconnect(true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }





        void LabelURLClick(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.vkmodule.com.ua");
        }

        void TmrConStateTick(object sender, EventArgs e)
        {
            try
            {
                if (clientSocket.Connected)
                {
                    picConState.BackgroundImage = imgListConnection.Images["Conn_Green"];
                    lblConState.Text = "Open";
                }
                else
                {
                    picConState.BackgroundImage = imgListConnection.Images["Conn_Red"];
                    lblConState.Text = "Closed";
                }
            }
            catch (Exception er)
            {
                ;
            }
        }

    }
}
